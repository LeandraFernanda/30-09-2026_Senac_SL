import { useState } from "react"

const SpotifyLogo = () => (
  <svg viewBox="0 0 167 50" fill="white" xmlns="http://www.w3.org/2000/svg" aria-label="Spotify" className="w-36">
    <path d="M25 0C11.193 0 0 11.193 0 25s11.193 25 25 25 25-11.193 25-25S38.807 0 25 0zm11.463 36.071a1.558 1.558 0 01-2.143.519c-5.872-3.588-13.267-4.399-21.974-2.41a1.558 1.558 0 11-.695-3.036c9.533-2.18 17.71-1.241 24.294 2.785a1.558 1.558 0 01.518 2.142zm3.059-6.807a1.949 1.949 0 01-2.679.641C30.357 25.798 22.13 24.18 12.04 27.028a1.95 1.95 0 11-1.132-3.731c11.368-3.45 20.497-1.623 27.975 2.29a1.949 1.949 0 01.639 2.677zm.263-7.09c-7.124-4.232-18.883-4.62-25.683-2.555a2.339 2.339 0 11-1.358-4.477c7.81-2.37 20.79-1.913 28.993 2.953a2.34 2.34 0 01-2.952 3.618v.46z"/>
    <path d="M71.655 22.194c-4.22-1.008-4.973-1.716-4.973-3.203 0-1.403 1.322-2.346 3.29-2.346 1.91 0 3.805.717 5.784 2.194a.392.392 0 00.551-.087l2.45-3.452a.391.391 0 00-.08-.543c-2.38-1.888-5.054-2.805-8.654-2.805-4.872 0-8.272 2.92-8.272 7.093 0 4.468 2.929 6.042 7.677 7.222 4.033.929 4.709 1.72 4.709 3.115 0 1.546-1.38 2.506-3.604 2.506-2.467 0-4.482-.83-6.736-2.783a.393.393 0 00-.555.047l-2.747 3.266a.391.391 0 00.043.548c2.638 2.338 5.878 3.572 9.9 3.572 5.291 0 8.714-2.866 8.714-7.302-.001-3.743-2.231-5.826-7.497-7.042zM88.58 17.5c-2.278 0-4.15.897-5.685 2.735v-2.144a.391.391 0 00-.391-.391h-4.505a.391.391 0 00-.391.391v22.834a.391.391 0 00.391.391h4.505a.391.391 0 00.391-.391V34.82c1.535 1.726 3.407 2.567 5.685 2.567 4.228 0 8.507-3.255 8.507-9.944s-4.279-9.943-8.507-9.943zm3.49 9.943c0 3.282-2.023 5.567-4.922 5.567-2.87 0-5.03-2.39-5.03-5.567 0-3.178 2.16-5.567 5.03-5.567 2.871 0 4.922 2.33 4.922 5.567zM108.264 17.5c-5.745 0-10.237 4.39-10.237 10.034 0 5.575 4.464 9.853 10.237 9.853 5.774 0 10.27-4.363 10.27-9.943-.001-5.612-4.468-9.944-10.27-9.944zm0 15.522c-2.995 0-5.234-2.352-5.234-5.578 0-3.235 2.155-5.508 5.234-5.508 3.005 0 5.264 2.344 5.264 5.508.001 3.216-2.177 5.578-5.264 5.578zM128.686 17.5c-5.745 0-10.237 4.39-10.237 10.034 0 5.575 4.465 9.853 10.237 9.853 5.774 0 10.27-4.363 10.27-9.943-.001-5.612-4.468-9.944-10.27-9.944zm0 15.522c-2.994 0-5.234-2.352-5.234-5.578 0-3.235 2.155-5.508 5.234-5.508 3.005 0 5.264 2.344 5.264 5.508.001 3.216-2.176 5.578-5.264 5.578zM149.714 23.59l-5.573-5.887a.391.391 0 00-.574.004l-.002.002-5.546 5.882a.39.39 0 00.286.657h3.15v12.703a.391.391 0 00.391.391h4.04a.391.391 0 00.391-.391V24.248h3.15a.39.39 0 00.287-.657z"/>
  </svg>
)

const GoogleIcon = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5" aria-hidden="true">
    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
  </svg>
)

const FacebookIcon = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5" aria-hidden="true">
    <path fill="#1877F2" d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
  </svg>
)

const AppleIcon = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5" aria-hidden="true" fill="white">
    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
  </svg>
)

export default function App() {
  const [email, setEmail] = useState("")
  const [emailFocused, setEmailFocused] = useState(false)

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-sm flex flex-col items-center gap-6">

        {/* Spotify Logo */}
        <div className="mb-2">
          <SpotifyLogo />
        </div>

        <h1 className="text-white text-3xl font-bold text-center leading-tight">
          Entrar no Spotify
        </h1>

        {/* Email field */}
        <div className="w-full flex flex-col gap-1.5">
          <label htmlFor="email" className="text-white text-sm font-semibold">
            Endereço de e-mail ou nome de usuário
          </label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            onFocus={() => setEmailFocused(true)}
            onBlur={() => setEmailFocused(false)}
            placeholder="E-mail ou nome de usuário"
            className="w-full bg-[#2a2a2a] text-white placeholder-[#6a6a6a] rounded-sm px-4 py-3 text-sm border transition-colors duration-150 outline-none"
            style={{
              borderColor: emailFocused ? "#fff" : "#3e3e3e",
              borderWidth: "1px",
            }}
          />
        </div>

        {/* Continue button */}
        <button
          className="w-full bg-[#1ed760] hover:bg-[#1fdf64] active:scale-[0.98] text-black font-bold text-sm rounded-full py-3 transition-all duration-150"
        >
          Continuar
        </button>

        {/* Divider */}
        <div className="w-full flex items-center gap-3">
          <div className="flex-1 h-px bg-[#2a2a2a]" />
          <span className="text-[#a3a3a3] text-xs font-semibold tracking-wide">ou</span>
          <div className="flex-1 h-px bg-[#2a2a2a]" />
        </div>

        {/* Social / alternate login buttons */}
        <div className="w-full flex flex-col gap-3">
          <SocialButton icon={<span className="text-white text-base">📱</span>} label="Continuar com um número de telefone" />
          <SocialButton icon={<GoogleIcon />} label="Continuar com o Google" />
          <SocialButton icon={<FacebookIcon />} label="Continuar com o Facebook" />
          <SocialButton icon={<AppleIcon />} label="Continuar com a Apple" />
        </div>

        {/* Divider */}
        <div className="w-full h-px bg-[#2a2a2a]" />

        {/* Sign up */}
        <div className="flex flex-col items-center gap-1 pb-4">
          <span className="text-[#a3a3a3] text-sm">Não tem conta?</span>
          <a
            href="#"
            className="text-white text-sm font-semibold underline underline-offset-2 hover:text-[#1ed760] transition-colors duration-150"
          >
            Inscrever-se no Spotify
          </a>
        </div>
      </div>
    </div>
  )
}

function SocialButton({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <button
      className="w-full flex items-center border border-[#727272] hover:border-white rounded-full py-3 px-4 gap-4 transition-colors duration-150 group"
    >
      <span className="flex items-center justify-center w-5 h-5 shrink-0">{icon}</span>
      <span className="flex-1 text-center text-white text-sm font-semibold group-hover:text-white pr-5">
        {label}
      </span>
    </button>
  )
}
